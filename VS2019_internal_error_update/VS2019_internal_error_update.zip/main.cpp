#include <iostream>
#include "flags.h"

void main() {

	std::cout << "ok! " << std::endl;
}